//package multitask;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.ImageIcon;
import javax.swing.JPanel;
import javax.swing.Timer;
import java.awt.geom.*;
import java.awt.event.ActionEvent;
import java.util.*;

public class AllGames2 extends JPanel implements ActionListener, KeyListener
{
	private boolean gameIsOver;
	private final int SECOND = 1000;
	
	//MOVINGBLOCK
	private static final long serialVersionUID = 1L;
    private Timer t = new Timer(5, this);
    private Timer timer;
    private double x = 350, y = 350, vely = 0;
    private Rectangle2D rectT;
    private int i = 0; int n = 0; int a = 0; int c = 0; int test = 0; int numArrows = 0;
    private ArrayList<triPoints> triPts = new ArrayList<triPoints>();;
    private long time;
    int count = 0;
    
    //JUMPINGOVER
	final static int high2 = 200;
	Graphics2D g2, rect, rect2, rect3; 
	Image image2;
    private int x2 = 100, y2 = 400, finaly2 = 400;
    private double vely2;
    private int rectX = 0, rectX2 = 800, rectX3 = 800;
    private int test2 = 0;
    
    final static int HEIGHT2 = 20;
    int length2;
    
    boolean inAir;
    Timer timer2;
    Timer t2 = new Timer(5, this);
    
    //MOVINGBALL
	private int diff3;
	double x3 = 0, y3 = 0, velx3 = 0, vely3 = 0;
	Timer timer3;
	Timer t3 = new Timer(50, this);;
	private long time3;
	private ArrayList<SquareTimer> sqrs3 = new ArrayList<SquareTimer>();
	
    public AllGames2() 
	{
    	gameIsOver = false;
    	t.setInitialDelay(SECOND*20);
    	t2.setInitialDelay(SECOND*2);
    	
    	//JUMPINGOVER
		setBackground(new Color(204, 153, 255)); //204, 153, 255
		t2.start();
		addKeyListener(this);
		setFocusable(true);
		setFocusTraversalKeysEnabled(false);
		image2 = new ImageIcon(getClass().getResource("/Images/halfcircle.jpg")).getImage();
		ActionListener animate2 = new ActionListener() 
		{
            public void actionPerformed(ActionEvent ae) 
            {
                repaint();
            }
        };
        timer2 = new Timer(100,animate2);
        timer2.start(); 
        vely2 = 0;
        inAir = false;
    	
    	//MOVINGBLOCK
    	setOpaque(true);
        t.start();
        addKeyListener(this);
        setVisible(true);
        setFocusable(true);
        setFocusTraversalKeysEnabled(false);
        
        ActionListener animate = new ActionListener() 
        {
            public void actionPerformed(ActionEvent ae) 
            {
                    repaint();                
            }
        };
        int rand = (int) (Math.random()*5+1);
        timer = new Timer (rand*100,animate);

        timer.start();
        time = System.currentTimeMillis();
        
        //MOVINGBALL
		t3.start();
		addKeyListener(this);
		setFocusable(true);
		setFocusTraversalKeysEnabled(false);
		diff3=0;

		ActionListener animate3 = new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                repaint();                }
        };
        
		timer3 = new Timer (2000,animate3);
		
		timer3.start();
		time3 = System.currentTimeMillis();
    	
	}
    
    public void paintComponent(Graphics g) 
    {
    	//MOVINGBLOCK
    	super.paintComponent(g);
        Graphics2D g1 = (Graphics2D) g;
        g1.drawRect(347, 64, 26, 425);
        g1.setColor(new Color(0, 0, 204));
        rectT = new Rectangle2D.Double(x, y, 20, 70);
        g1.fill(rectT);
        
        test = (int) (Math.random()*2+1); //direction of shape
        
        g1.setColor(Color.red);
        int[] xPt1 = {(60+i), (85+i), (60+i), 60+i};
        int[] xPt2 = {650-i, 623-i, 650-i, 650-i};
        
        if(System.currentTimeMillis()-time>150 && numArrows<=3)
        {
            c = (int) (Math.random()*5+1); //arrows y loc 
            int[] yPt = {80+c*50, 100+c*50, 120+c*50, 80+50*c};
            if (test==1) 
            {
                triPts.add(new triPoints(xPt1,yPt,0));                
                numArrows++;
            }
            else 
            {
                triPts.add(new triPoints(xPt2,yPt,0));
                numArrows++;
            }
            time = System.currentTimeMillis();
        }
        
        changeColor(g1);
        i+=2;
        if (n < 160) 
        {
        	n += 10;
        }
        Toolkit.getDefaultToolkit().sync();
        
        //JUMPINGOVER        
        if(inAir)
        	vely2 -= .08;
        
        y2 -= vely2;
        
		g2 = (Graphics2D) g;
        g.drawImage(image2,x2,y2,null);
    
        
        //this one changes how long the first length has to be
    	if (test2 == 0) 
    	{
    		length2 = (int) Math.random()*10+7;
    		length2 = 100*length2;
    		rectX2 = rectX +length2;
    		rectX3 = rectX2 + 150;
    	}
    	paintRect1(g);
    	paintRect2(g);
    	paintRect3(g);
    	
        test2+=2;
        
        if(y2 < finaly2)
        	inAir = true;
        else {
        	y2 = finaly2;
        	inAir = false;
        }
        
        //MOVINGBALL
		Graphics2D g3 = (Graphics2D) g;
		g3.setColor(new Color (0, 170, 0));
		g3.fill(new Ellipse2D.Double(x3, y3, 40, 40));	
		
		int xCoor = (int) (Math.random()*660+20);
		int yCoor = (int) (Math.random()*460+20);
		
		if (System.currentTimeMillis()-time3 > 3000-diff3*100) {
			sqrs3.add(new SquareTimer(xCoor,yCoor));
			time3 = System.currentTimeMillis();
			diff3++;
		}
		
		putSquare(g);
		
        

		Toolkit.getDefaultToolkit().sync();
		
        //GAMEOVER TEST
        if (collisionJO() == false) 
        {
        	t.stop();
        	timer.stop();
        	t2.stop();
        	timer2.stop();
        	t3.stop();
        	timer3.stop();
        	System.out.print("game over");
        }
        else if(collisionT() == true)
        {
        	System.out.print("Game Over");
        	t.stop();
        	timer.stop();
        	t2.stop();
        	timer2.stop();
        	t3.stop();
        	timer3.stop();
        }
        else if (sqrs3.size() > 6) 
        {
        	System.out.print("gameOver ");
        	t.stop();
        	timer.stop();
        	t2.stop();
        	timer2.stop();
        	t3.stop();
        	timer3.stop();
        }
    }
    
  //MOVINGBLOCK
    public void changeColor(Graphics g)
    {
    	Graphics2D g1 = (Graphics2D) g;
    	for(int j = triPts.size()-1; j>0; j--){        
            triPoints place = triPts.get(j);
            
            if(place.getX()[0] > 650 || place.getX()[0] == 0)
            {
            	triPts.remove(j);
            	numArrows--;
            }     	
            
            else{
            g1.fillPolygon(place.getX(), place.getY(), 4);
            place.move();
            
            if(place.getLength()>60)
            {
                if (a < 160) 
                {
                    a += 1;
                }
                if (a == 160) 
                {
                    i = 0;
                }
            }
                
            }
         }
       }
    
    //MOVINGBLOCK
    public boolean collisionT()
    {
        gameIsOver = false;
        
        if(numArrows > 0)
        {
        	for(int a = 1; a<=numArrows; a++)
        	{
        		triPoints pts = triPts.get(a-1);
        		Rectangle triangle = new Rectangle(pts.getX()[0]-6,pts.getY()[0], 28, 35);
        		if(rectT.intersects(triangle))
        			gameIsOver = true;
        	}
        }
        return gameIsOver;
    }
    
    
    //JUMPINGOVER
    public void paintRect1(Graphics g) 
    {
    	//painting the first rectangle whose length can be changed
    	rect = (Graphics2D) g;
		rect.setColor(Color.black);
		rect.fill(new Rectangle2D.Double(rectX, finaly2+23, length2, HEIGHT2));
        rectX-=2;
	    if (rectX == -length2)
	    {
	     	 rectX = 800;	     
	    }
    }
    //JUMPINGOVER
    public void paintRect2(Graphics g) 
    {
    	//painting the space between lengths so maybe later the collision could be if (inAir == false && x == rectX2)
    	rect2 = (Graphics2D) g;
	    rect2.setColor(new Color(204,153,255));
	    rect2.fill(new Rectangle2D.Double(rectX2, finaly2+23, 150, HEIGHT2));
	    rectX2-=2;
	    if (rectX2 == -150) 
	    {
	    	rectX2 = rectX+length2;
    	}
    }
    //JUMPINGOVER
    public void paintRect3(Graphics g) 
    {
    	//painting the length of rectangle after the space because the first rectangle cannot be erased yet. 
    	//these rectangles will still have to be adjusted to deal with the changing lengths, the spaces, and collisions
    	rect3 = (Graphics2D) g;
     	rect3.setColor(Color.black);
     	rect3.fill(new Rectangle2D.Double(rectX3, finaly2+23, 650, HEIGHT2));
     	rectX3-=2;
    	if (rectX3 == -650) 
    	{
    		rectX3 = rectX+length2+150;
    		test2 = 0;
    	}
    }
    //JUMPINGOVER
    public boolean collisionJO() 
    {
    	if (inAir == false && x2 >=rectX2 && x2+20<rectX3) 
    	{
    		// gameOver();
    		//comment out all gameOver() because that's in the overall class
    		t2.stop();
    		timer2.stop();
    		gameIsOver = true;
    		return false;
    	}
    	return true;
    }
    
    
    
    
    //MOVINGBALL
    public void putSquare(Graphics g)
    {
    	Graphics2D g2 = (Graphics2D) g;
    	g2.setColor(new Color (0, 200, 0));
        g2.setStroke(new BasicStroke(4));
        
        
    	for(int j = sqrs3.size()-1; j>0; j--){        
            SquareTimer place = sqrs3.get(j);
           
            g2.drawRect(place.getX(), place.getY(), 60,60);
            
            if (collisionB(place) == true) {
            	sqrs3.remove(j);
            	g2 = null;
            }
    	}
    }
    
    //MOVINGBALL
    public boolean collisionB(SquareTimer s) 
    {
			Rectangle r1 = new Rectangle();
			r1.setBounds((int) x3,(int) y3, 35, 35);
			Rectangle r2 = new Rectangle();
			r2.setBounds(s.getX(), s.getY(),60,60);
			if (r1.intersects(r2)) {
				s.remove();
				return true;
		}
		return false;
	}
    
    public void actionPerformed(ActionEvent e) 
    {
    	//MOVINGBLOCK
        if(collisionT() == false)
        {
            repaint();
            
            if(y >= 350) {
                y = 350;
            }
            if(y<= 80) {
                y = 80;
            }
            y += vely;
        }
        else
        {
        	t.stop();
        	timer.stop();
        	System.out.print("Game Over");
        }
        //JUMPINGOVER NONE
        
        //MOVINGBALL
        x3 += velx3;
		y3 += vely3;
		if (x3 <= 10) {
			x3 = 10;
		}
		if (x3 >= 790) {
			x3 = 790;
		}
		if (y3 <= 10) {
			y3 = 10;			
		}
		if (y3 >= 590) {
			y3 = 590;
		}
		
		repaint();
        
    }

    public void keyPressed(KeyEvent e) 
    {
        int code = e.getKeyCode();
        //MOVINGBLOCK
        if (code == KeyEvent.VK_UP) 
        {
            vely = -2.0;
        }
        if (code == KeyEvent.VK_DOWN) 
        {
            vely = 2.0;
        }
        
        //JUMPINGOVER
        if (code == KeyEvent.VK_SPACE) 
        {
    		if(!inAir)
    			vely2 = 4;
        }
        
        //MOVINGBALL
        if (code == KeyEvent.VK_W) {
			vely3 = -5.0;
		}
		if (code == KeyEvent.VK_S) {
			vely3 = 5.0;
		}
		if (code == KeyEvent.VK_A) {
			velx3 = -5.0;
		}
		if (code == KeyEvent.VK_D) {
			velx3 = 5.0;
		}
        
    }   

    public void keyReleased(KeyEvent e) 
    {
        int code = e.getKeyCode();
        //MOVINGBLOCK
        if (code == KeyEvent.VK_UP) 
        {
            vely = 0;
        }
        if (code == KeyEvent.VK_DOWN) 
        {
            vely = 0;
        }
        //JUMPINGOVER NONE
        
        //MOVINGBALL
        if (code == KeyEvent.VK_W) {
			vely3 = 0;
		}
		if (code == KeyEvent.VK_S) {
			vely3 = 0;
		}
		if (code == KeyEvent.VK_A) {
			velx3 = 0;
		}
		if (code == KeyEvent.VK_D) {
			velx3 = 0;
		}
    }

    public void keyTyped(KeyEvent e) {}

    public void update(){}
    
    public boolean gameOver()
    {
    	return gameIsOver;
    }
    
}
